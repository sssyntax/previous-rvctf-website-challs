from flask import Flask, request, jsonify, render_template, redirect, url_for, Response
import sqlite3
import jwt
from functools import wraps

app = Flask(__name__)
app.secret_key = "avrillavigne"  # Secret key for JWT generation
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Database setup (create users table if it doesn"t exist)
def init_db():
    with open("database.db", "w"):
        pass # clear this file
    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS users (username TEXT, password TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS notes (title TEXT, content TEXT, id INT, date TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS t0p_s3cr3t_n0t3s (title TEXT, content TEXT, id INT, date TEXT)")
    c.execute("INSERT INTO users (username, password) VALUES ('sarah', 'th1s_p4ssw0rd_15_v3ry_s4f3!!!1!1!!!1!')")
    c.execute("INSERT INTO t0p_s3cr3t_n0t3s (title, content, id, date) VALUES ('DO NOT SHARE - THE FLAG', 'The part 2 flag is: IRS{n1c3_n0t3s_s4r4h!}', 1, 'today')")
    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('Math - Algebra Notes', 'This note covers basic algebraic operations and equations.', 1, 'today')")
    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('Math - Geometry Notes', 'Notes on geometry, angles, and shapes like triangles and circles.', 2, 'today')")
    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('Math - Calculus Notes', 'Introduction to limits, derivatives, and integrals in calculus.', 3, 'today')")
    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('Math - Trigonometry Notes', 'Study of trigonometric functions, sine, cosine, and tangent.', 4, 'today')")

    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('Science - Biology Notes', 'Notes on cell biology, genetics, and human anatomy.', 5, 'today')")
    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('Science - Chemistry Notes', 'Study of chemical reactions, periodic table, and atomic structure.', 6, 'today')")
    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('Science - Physics Notes', 'Concepts of force, motion, and energy in classical physics.', 7, 'today')")
    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('Science - Environmental Science Notes', 'Study of ecosystems, pollution, and climate change.', 8, 'today')")

    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('History - Ancient Civilizations Notes', 'Notes on Mesopotamia, Egypt, and ancient Greece.', 9, 'today')")
    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('History - World War I Notes', 'Study of the causes, major battles, and outcomes of WWI.', 10, 'today')")
    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('History - World War II Notes', 'Key events, figures, and strategies during WWII.', 11, 'today')")
    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('History - The Renaissance Notes', 'Overview of the Renaissance period and major contributors to art and science.', 12, 'today')")

    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('Literature - Shakespeare Notes', 'Study of the works of William Shakespeare and his impact on literature.', 13, 'today')")
    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('Literature - Romanticism Notes', 'Notes on the Romantic movement in literature and its key authors.', 14, 'today')")
    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('Literature - Modernism Notes', 'Analysis of modernist writers like James Joyce and T.S. Eliot.', 15, 'today')")
    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('Literature - American Literature Notes', 'Key themes in American literature from the 19th century to today.', 16, 'today')")

    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('Geography - Continents and Oceans Notes', 'Study of the seven continents and five oceans on Earth.', 17, 'today')")
    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('Geography - Climate Zones Notes', 'Understanding the different climate zones around the world.', 18, 'today')")
    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('Geography - Population Distribution Notes', 'Analysis of population distribution and urbanization patterns.', 19, 'today')")
    c.execute("INSERT INTO notes (title, content, id, date) VALUES ('Geography - Natural Disasters Notes', 'Study of earthquakes, hurricanes, and other natural disasters.', 20, 'today')")
    conn.commit()
    conn.close()

init_db()

# Function to verify the JWT token
def token_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = None
        if "token" in request.cookies:
            token = request.cookies.get("token")

        if not token:
            return jsonify({"message": "Token is missing!"}), 403
        
        try:
            # Decode the token using the secret key and check expiration
            data = jwt.decode(token, app.secret_key, algorithms=["HS256"])
            current_user = data["username"]
        except jwt.ExpiredSignatureError:
            return jsonify({"message": "Token has expired!"}), 403
        except jwt.InvalidTokenError:
            return jsonify({"message": "Invalid token!"}), 403

        # Pass the current_user (username) to the route
        return f(current_user, *args, **kwargs)
    return decorated_function

# Route for the login page
@app.route("/")
def index():
    if not "token" in request.cookies:
      return render_template("login.html")
    return redirect("/home")

# Login route
@app.route("/login", methods=["POST"])
def login():

    username = request.form["username"]
    password = request.form["password"]

    if "1=1" in username + password:
        return "WHY WOULD YOUR PASSWORD CONTAIN 1=1? GO AWAY HACKER!"

    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    print(f"SELECT * FROM users WHERE username = '{username}' AND password = '{password}'")
    c.execute(f"SELECT * FROM users WHERE username = '{username}' AND password = '{password}'")
    user = c.fetchone()
    conn.close()

    if user:
        token = jwt.encode(
            {"username": user[0]},
            app.secret_key,
            algorithm="HS256"
        )
        response = redirect("/home")
        response.set_cookie("token", token)
        return response

    return "INVALID CREDENTIALS!!!"

@app.route("/home", methods=["POST", "GET"])
@token_required
def home(username):
    if request.method == "GET":
        return render_template("home.html", username=username)
    elif request.method == "POST":
        title = request.form.get("title")
        conn = sqlite3.connect("database.db")
        c = conn.cursor()
        c.execute(f"SELECT * FROM notes WHERE title LIKE '%{title}%'")
        notes = c.fetchall()
        conn.close()
        return render_template("home.html", username=username, notes=notes)


if __name__ == "__main__":
    app.run("0.0.0.0", 8010, debug=True) # leave this be