# Flags

SarahsQualityLearning part 1: IRS{my_f1rs7_b4by_sqli_st3ps}
SarahsQualityLearning part 2: IRS{n1c3_n0t3s_s4r4h!}
SarahsQualityLearning part 3: IRS{h3_w4s_a_sk8er_b0y}