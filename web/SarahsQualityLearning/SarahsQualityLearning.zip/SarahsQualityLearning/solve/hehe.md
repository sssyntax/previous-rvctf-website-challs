first step login as sarah, but u see 1=1 is not allowed, so you go hmmm it doesnt have to be one and put 2=2 instead, very nice 

second step, notice how there are 4 collums, so since its an SQL challenge u go do union select of
' UNION SELECT NULL, NULL, NULL, sqlite_version()--, returns 3.40 something, hence do
' UNION SELECT NULL, NULL, NULL, sql FROM sqlite_master WHERE type='table'--, u will see the following collumns of users and t0p_s3cret_table thing so just modify the request to see the flag,
' UNION SELECT NULL, NULL, title, content FROM t0p_s3cr3t_n0t3s--

last step, brute force the jwt token, sign the cookie and win the challenge by replacing the cookie in the home page