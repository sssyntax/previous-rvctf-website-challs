# Description

Sarah the studious has created a website to help her study. Let's crack into this website and steal her SECRET notes!

# Difficulty

SarahsQualityLearning part 1 difficulty: easy
SarahsQualityLearning part 2 difficulty: medium
SarahsQualityLearning part 3 difficulty: medium